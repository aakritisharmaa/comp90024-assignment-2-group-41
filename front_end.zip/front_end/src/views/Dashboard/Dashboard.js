import React, { useState } from 'react';
import { makeStyles } from '@material-ui/styles';
import { Grid, Typography, Paper } from '@material-ui/core';
import { Budget, LatestSales } from './components';
import TopAllTime from './components/TopAllTime';
import Top24Hours from './components/Top24Hours';
import palette from 'theme/palette';
import img from '../../dashboard.png';
const useStyles = makeStyles(theme => ({
  root: {
    padding: theme.spacing(4)
  }
}));
const realFetch = async searchParams => {
  const url = 'http://172.26.130.208:3000';
  const response = await fetch(`${url}/word?key=${searchParams}`, {
    mode: 'cors'
  });
  const parsedData = await response.json();
  const formattedData = parsedData.json;
  const labels = [
    'Boroondara',
    'Stonnington - East',
    'Stonnington - West',
    'Bayside',
    'Port Phillip',
    'Glen Eira',
    'Yarra',
    'Melbourne City',
    'Darebin - South',
    'Essendon',
    'Brunswick - Coburg',
    'Hobsons Bay',
    'Maribyrnong'
  ];
  const data2020 = labels.map(label => formattedData['2020'][label]);
  const data2014 = labels.map(label => formattedData['2014'][label]);
  const chartData = {
    labels,
    datasets: [
      {
        label: '2020',
        backgroundColor: palette.primary.main,
        data: data2020
      },
      {
        label: '2014',
        backgroundColor: palette.neutral,
        data: data2014
      }
    ]
  };
  return chartData;
};

const Dashboard = () => {
  const classes = useStyles();
  const [data, setData] = useState(null);
  const fetchAndSetData = async searchParams => {
    const chartData = await realFetch(searchParams);
    setData(chartData);
  };
  return (
    <div className={classes.root}>
      <Grid
        container
        spacing={4}
      >
        <Grid
          item
          lg={6}
          sm={6}
          xl={6}
          xs={6}
        >
          <Budget fetchData={searchParams => fetchAndSetData(searchParams)} />
        </Grid>

        <Grid
          item
          lg={6}
          sm={6}
          xl={6}
          xs={6}
        >
          <img
            src={img}
            style={{ width: 500, height: 500 }}
          />
        </Grid>
        <Grid
          item
          lg={12}
          md={12}
          xl={9}
          xs={12}
        >
          <LatestSales data={data} />
        </Grid>

        <Grid
          item
          lg={6}
          md={6}
          xl={6}
          xs={6}
        >
          <TopAllTime label="Highest Information Gain: 2020" />
        </Grid>
        <Grid
          item
          lg={6}
          md={6}
          xl={6}
          xs={6}
        >
          <Top24Hours label="Highest Information Gain: 2014" />
        </Grid>
      </Grid>
    </div>
  );
};

export default Dashboard;
