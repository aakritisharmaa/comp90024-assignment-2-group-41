import React, { useState, useEffect } from 'react';
import clsx from 'clsx';
import TablePlaceHolder from '../TablePlaceHolder';
import PerfectScrollbar from 'react-perfect-scrollbar';
import PropTypes from 'prop-types';
import { makeStyles } from '@material-ui/styles';
import {
  Card,
  CardHeader,
  CardContent,
  Divider,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow
} from '@material-ui/core';

import mockData from './data';

const useStyles = makeStyles(theme => ({
  root: {},
  content: {
    padding: 0
  },
  inner: {
    minWidth: 800
  },
  statusContainer: {
    display: 'flex',
    alignItems: 'center'
  },
  status: {
    marginRight: theme.spacing(1)
  },
  actions: {
    justifyContent: 'flex-end'
  }
}));

const TopAllTime = props => {
  const { label, className, ...rest } = props;

  const classes = useStyles();

  const [data, setData] = useState(null);
  useEffect(() => {
    const realFetch = async () => {
      const url = 'http://172.26.130.208:3000';
      const response = await fetch(url);
      console.log(response);
      const parsedData = await response.json();
      console.log('Parsed Data:');
      const formattedData = parsedData.json;
      setData(
        Object.entries(formattedData['2020'])
          .map(([type, someFloat]) => {
            return { type, someFloat };
          })
          .slice(0, 10)
      );
    };
    realFetch();
  }, []);
  return (
    <Card
      {...rest}
      className={clsx(classes.root, className)}
    >
      <CardHeader title={label} />
      <Divider />
      <CardContent className={classes.content}>
          <div className={classes.inner}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Term</TableCell>
                  <TableCell>Information Gain</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {data ? (
                  data.map(order => (
                    <TableRow
                      hover
                      key={order.id}
                    >
                      <TableCell>{order.type}</TableCell>
                      <TableCell>{order.someFloat}</TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TablePlaceHolder />
                )}
              </TableBody>
            </Table>
          </div>
      </CardContent>
      <Divider />
    </Card>
  );
};

TopAllTime.propTypes = {
  className: PropTypes.string
};

export default TopAllTime;
