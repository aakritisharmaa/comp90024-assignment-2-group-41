import React from 'react';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import { makeStyles } from '@material-ui/styles';
import { Card, CardContent, Grid, Typography } from '@material-ui/core';
import { SearchInput } from 'components';
import text from './text';
const useStyles = makeStyles(theme => ({
  root: {
    height: '100%'
  },
  content: {
    alignItems: 'center',
    display: 'flex'
  },
  title: {
    fontWeight: 700
  },
  avatar: {
    backgroundColor: theme.palette.error.main,
    height: 56,
    width: 56
  },
  icon: {
    height: 32,
    width: 32
  },
  difference: {
    marginTop: theme.spacing(2),
    display: 'flex',
    alignItems: 'center'
  },
  differenceIcon: {
    color: theme.palette.error.dark
  },
  differenceValue: {
    color: theme.palette.error.dark,
    marginRight: theme.spacing(1)
  }
}));

const Budget = props => {
  const [value, setValue] = React.useState();
  const { className, fetchData, ...rest } = props;

  const classes = useStyles();
  const delay = new Promise(resolve => setTimeout(resolve, 1000));
  return (
    <Card
      {...rest}
      className={clsx(classes.root, className)}
    >
      <CardContent>
        <Grid
          container
          justify="space-between"
        >
          <Grid item>
            <Typography
              className={classes.title}
              gutterBottom
              variant="h5"
            >
              Search our database...
            </Typography>
            {/* <TextField
              onChange={event => setValue(event.target.value)}
              placeholder="Search"
              value={value}
              variant="outlined"
            /> */}
            <SearchInput
              className={classes.searchInput}
              onChange={e => setValue(e.target.value)}
              onKeyPress={e => (e.key === 'Enter' ? fetchData(value) : null)}
              placeholder="Search"
            />
            <Typography
              style={{ marginTop: '25px' }}
              variant="body1"
            >
              {text}
            </Typography>
          </Grid>
        </Grid>
      </CardContent>
    </Card>
  );
};

Budget.propTypes = {
  className: PropTypes.string
};

export default Budget;
