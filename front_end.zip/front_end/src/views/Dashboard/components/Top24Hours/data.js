import uuid from 'uuid/v1';
export default [
  {
    id: uuid(),
    type: 'house',
    someFloat: 0.5
  },
  {
    id: uuid(),
    type: 'tech',
    someFloat: 0.1
  },
  {
    id: uuid(),
    type: 'news',
    someFloat: 0.99
  },
  {
    id: uuid(),
    type: 'AFL',
    someFloat: 0.43
  },
  {
    id: uuid(),
    type: 'iphone',
    someFloat: 0.54
  },
  {
    id: uuid(),
    type: 'sony',
    someFloat: 0.76
  },
  {
    id: uuid(),
    type: 'auction',
    someFloat: 0.76
  },
  {
    id: uuid(),
    type: 'gym',
    someFloat: 0.76
  },
  {
    id: uuid(),
    type: 'run',
    someFloat: 0.76
  },
  {
    id: uuid(),
    type: 'dinner',
    someFloat: 0.76
  }
];
