import React from 'react';
import Skeleton from '@material-ui/lab/Skeleton';
const skeletons = Array.from(Array(10), (_, i) => (
  <Skeleton
    height={30}
    style={{ marginBottom: '20px' }}
    variant="rect"
    width={400}
  />
));
export default () => (
  <div style={{ marginLeft: '30px', marginTop: '30px' }}>{skeletons}</div>
);
