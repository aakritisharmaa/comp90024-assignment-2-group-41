export { default } from './LatestProducts';
