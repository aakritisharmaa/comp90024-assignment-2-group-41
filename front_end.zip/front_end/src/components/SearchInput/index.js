export { default } from './SearchInput';
